
public class Funcionario
{
    private int id;
    private String nome;
    private double salario;
    private Funcionario chefe;

    public Funcionario(int id, String nome, double salario){
        this.id = id;
        this.nome = nome;
        this.salario = salario;
    }

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public double getSalario() {
        return salario;
    }
    public void setSalario(double salario){
        this.salario = salario;
    }
    public void aumentaSalario(int percentual){
        salario *= 1 + (percentual/100);
    }
    public String toString(){
        return nome + "[id: " + id + "; salario: " + String.format("%.2f", salario) + "]";
    }
    public String getChefe(){
        return chefe.nome;
    }
    public void setChefe(Funcionario chefe){
        this.chefe = chefe;
    }
    
}
